/*******************************
 *-=TransitionalValue.inc.hpp=-*
 *******************************

 Auteur : Florian Dupeyron (My?terious)
 Description : Permet de gérer une valeur qui change au cours du temps.
*/

namespace time
{
	template<typename T>
	TransitionalValue::TransitionalValue() :
		m_time(0)
	{
	}

	template<typename T>
	TransitionalValue::~TransitionalValue()
	{
	}


	template<typename T>
	TransitionValue::setTime(const uint64_t t)
	{
		m_time_goal = t;
		m_time = 0;
		m_value_start = m_value; //On reprend la valeur de départ.
		
		if(m_value_current != m_value_goal)
		{
			m_run = true; //Il faut calculer !
		}
	}

	template<typename T>
	TransitionalValue::setGoal(const T value)
	{
		m_value_goal = value;
		reset();
	}

	template<typename T>
	TransitionalValue::setInterpolationCallback(InterpolationCallback iCallback)
	{
		m_interpolationCallback = iCallback;
	}

	template<typename T>
	void TransitionalValue::update_imp()
	{
		if(m_time <= m_time_goal)
		{
			//-=Ajout temps=-//
			m_time += m_delta;
			//-=Fin de la section=-//

			//-=calcul valeur=-//
			m_value = m_interpolationCallback(m_time, m_value_start, m_value_goal, m_time_goal);
			//-=Fin de la section=-//
		}
	}
}
