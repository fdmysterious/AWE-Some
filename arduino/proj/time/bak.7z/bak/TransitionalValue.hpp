/***************************
 *-=TransitionalValue.hpp=-*
 ***************************

 Auteur : Florian Dupeyron (My?terious)
 Description : Permet de gérer une valeur qui change au cours du temps.
*/
#ifndef HEADER_TIME_TRANSITIONALVALUE
#define HEADER_TIME_TRANSITIONALVALUE

//-=Inclusion des headers=-//
#include <Arduino.h>
#include <inttypes.h>
//-=Fin de la section=-//

namespace time
{
	template<typename T>
	class TransitionalValue : public DeltaObject
	{
		public:
		typedef T (*InterpolationCallback)(T x, T y1, T y2, T x2);

		public:
		TransitionalValue();
		virtual ~TransitionalValue();

		//-=Fonctions de réglage=-//
		void setTime(const uint64_t t); //Définit le temps que l'on doit mettre en millisecondes pour atteindre la valeur (0 = régime permanent)
		void setGoal(const T value);					//Définit la valeur que l'on doit atteindre.
		void setInterpolationCallback(InterpolationCallback iCallback);	//Permet d'assigner le callback d'interpolation
		//-=Fin de la section=-//
		
		//-=Obtention de la valeur=-//
		T value();
		//-=Fin de la section=-//
		
		protected:
		//-=Fonctions de mise à jour=-//
		virtual void update_imp();
		//-=Fin de la section=-//

		protected:
		//-=Variables=-//
		T		m_value_start;		//Valeur de départ
		T		m_value_current;	//Valeur courante
		T		m_value_goal;		//Valeur que l'on doit atteindre.

		uint64_t	m_time;			//Compte le temps restant pour atteindre la valeur.
		uint64_t	m_time_goal;		//temps final à atteindre

		bool		m_run;			//Permet de savoir s'il faut calculer des nouvelles valeurs ou non.
		//-=Fin de la section=-//

		//-=Callback=-//
		InterpolationCallback m_interpolationCallback;
		//-=Fin de la section=-//
	};
}

//-=Inclusion header template=-//
#include "TransitionalValue.inc.hpp"
//-=Fin de la section=-//


#endif
